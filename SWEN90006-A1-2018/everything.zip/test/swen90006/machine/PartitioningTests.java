package swen90006.machine;

import java.util.List;
import java.util.ArrayList;
import java.nio.charset.Charset;
import java.nio.file.Path;
import java.nio.file.Files;
import java.nio.file.FileSystems;

import org.junit.*;
import static org.junit.Assert.*;

public class PartitioningTests
{
  //Any method annotated with "@Before" will be executed before each test,
  //allowing the tester to set up some shared resources.
  @Before public void setUp()
  {
  }

  //Any method annotated with "@After" will be executed after each test,
  //allowing the tester to release any shared resources used in the setup.
  @After public void tearDown()
  {
  }

  //Any method annotation with "@Test" is executed as a test.
  @Test public void aTest()
  {
    //the assertEquals method used to check whether two values are
    //equal, using the equals method
    final int expected = 2;
    final int actual = 1 + 1;
    assertEquals(expected, actual);
  }

  @Test public void anotherTest()
  {
    List<String> list = new ArrayList<String>();
    list.add("a");
    list.add("b");

    //the assertTrue method is used to check whether something holds.
    assertTrue(list.contains("a"));
  }

  //Test test opens a file and executes the machine
  @Test public void aFileOpenTest()
  {
    final List<String> lines = readInstructions("examples/array.s");
    Machine m = new Machine();
    assertEquals(m.execute(lines), 45);
  }
  
  //To test an exception, specify the expected exception after the @Test
  @Test(expected = java.io.IOException.class) 
    public void anExceptionTest()
    throws Throwable
  {
    throw new java.io.IOException();
  }







//test valid EC 1
  @Test public void testEC1_V()
  {
    final List<String> lines = readInstructions("examples/testCase4EC1_V.s");
    Machine m = new Machine();
    assertEquals(m.execute(lines),300);
  }

    //test valid EC 2
  @Test public void testEC2_V()
  {
    final List<String> lines = readInstructions("examples/testCase4EC2_V.s");
    Machine m = new Machine();
    assertEquals(m.execute(lines),2);
  }

    //test valid EC 3
  @Test public void testEC3_V()
  {
    final List<String> lines = readInstructions("examples/testCase4EC3_V.s");
    Machine m = new Machine();
    assertEquals(m.execute(lines),100);
  }

    //test valid EC 4
  @Test public void testEC4_V()
  {
    final List<String> lines = readInstructions("examples/testCase4EC4_V.s");
    Machine m = new Machine();
    assertEquals(m.execute(lines),100);
  }

    //test valid EC 5
  @Test public void testEC5_V()
  {
    final List<String> lines = readInstructions("examples/testCase4EC5_V.s");
    Machine m = new Machine();
    assertEquals(m.execute(lines),100);
  }

    //test valid EC 6
  @Test public void testEC6_V()
  {
    final List<String> lines = readInstructions("examples/testCase4EC6_V.s");
    Machine m = new Machine();
    assertEquals(m.execute(lines),100);
  }

    //test valid EC 7
  @Test public void testEC7_V()
  {
    final List<String> lines = readInstructions("examples/testCase4EC7_V.s");
    Machine m = new Machine();
    assertEquals(m.execute(lines),100);
  }

    //test valid EC 8
  @Test public void testEC8_V()
  {
    final List<String> lines = readInstructions("examples/testCase4EC8_V.s");
    Machine m = new Machine();
    assertEquals(m.execute(lines),200);
  }

    //test valid EC 9
  @Test public void testEC9_V()
  {
    final List<String> lines = readInstructions("examples/testCase4EC9_V.s");
    Machine m = new Machine();
    assertEquals(m.execute(lines),0);
  }

    //test valid EC 10
  @Test public void testEC10_V()
  {
    final List<String> lines = readInstructions("examples/testCase4EC10_V.s");
    Machine m = new Machine();
    assertEquals(m.execute(lines),100);
  }

    //test invalid EC 1
    @Test (expected = InvalidInstructionException.class)
    public void testEC1_I()
    {
        final List<String> lines = readInstructions("examples/testCase4EC1_I.s");
        Machine m = new Machine();
        m.execute(lines);
    }

    //test invalid EC 2
    @Test (expected = InvalidInstructionException.class)
    public void testEC2_I()
    {
        final List<String> lines = readInstructions("examples/testCase4EC2_I.s");
        Machine m = new Machine();
        m.execute(lines);
    }

    //test invalid EC 3
    @Test (expected = InvalidInstructionException.class)
    public void testEC3_I()
    {
        final List<String> lines = readInstructions("examples/testCase4EC3_I.s");
        Machine m = new Machine();
        m.execute(lines);
        throw new InvalidInstructionException();
    }

  @Test (timeout = 1000,expected = NoReturnValueException.class)
  public void testEC4_I()
  {
    final List<String> lines = readInstructions("examples/testCase4EC4_I.s");
    Machine m = new Machine();
    try {
      m.execute(lines);
    } catch (Exception e) {
      throw new NoReturnValueException();
    }
  }

  //Read in a file containing a program and convert into a list of
  //string instructions
  private List<String> readInstructions(String file)
  {
    Charset charset = Charset.forName("UTF-8");
    List<String> lines = null;
    try {
      lines = Files.readAllLines(FileSystems.getDefault().getPath(file), charset);
    }
    catch (Exception e){
      System.err.println("Invalid input file! (stacktrace follows)");
      e.printStackTrace(System.err);
      System.exit(1);
    }
    return lines;
  }
}
