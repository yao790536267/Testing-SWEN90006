package swen90006.machine;

import java.util.List;
import java.util.ArrayList;
import java.nio.charset.Charset;
import java.nio.file.Path;
import java.nio.file.Files;
import java.nio.file.FileSystems;

import org.junit.*;
import static org.junit.Assert.*;

public class BoundaryTests
{
  //Any method annotated with "@Before" will be executed before each test,
  //allowing the tester to set up some shared resources.
  @Before public void setUp()
  {
  }

  //Any method annotated with "@After" will be executed after each test,
  //allowing the tester to release any shared resources used in the setup.
  @After public void tearDown()
  {
  }

  //Any method annotation with "@Test" is executed as a test.
  @Test public void aTest()
  {
    //the assertEquals method used to check whether two values are
    //equal, using the equals method
    final int expected = 2;
    final int actual = 1 + 1;
    assertEquals(expected, actual);
  }

  @Test public void anotherTest()
  {
    List<String> list = new ArrayList<String>();
    list.add("a");
    list.add("b");

    //the assertTrue method is used to check whether something holds.
    assertTrue(list.contains("a"));
  }

  //Test test opens a file and executes the machine
  @Test public void aFileOpenTest()
  {
    final List<String> lines = readInstructions("examples/array.s");
    Machine m = new Machine();
    assertEquals(m.execute(lines), 45);
  }
  
  //To test an exception, specify the expected exception after the @Test
  @Test(expected = java.io.IOException.class) 
    public void anExceptionTest()
    throws Throwable
  {
    throw new java.io.IOException();
  }

















    //boundary tests for valid EC 1,2,3,5,6
    @Test(expected = InvalidInstructionException.class)
    public void boundaryTest4EC1n2n3n5n6_a()
    {
        final List<String> lines = readInstructions("examples/boundaryTest4EC1n2n3n5n6_a.s");
        Machine m = new Machine();
        assertEquals(m.execute(lines),300);
    }

    //boundary tests for valid EC 3
    @Test public void boundaryTest4EC3()
    {
        final List<String> lines = readInstructions("examples/boundaryTest4EC3.s");
        Machine m = new Machine();
        m.execute(lines);
    }

    //boundary tests for valid EC 4,5
    @Test(expected = InvalidInstructionException.class)
    public void boundaryTest4EC4n5()
    {
        final List<String> lines = readInstructions("examples/boundaryTest4EC4n5.s");
        Machine m = new Machine();
        m.execute(lines);
    }

    //boundary tests for valid EC 4,5,6
    @Test(expected = InvalidInstructionException.class)
    public void boundaryTest4EC4n5n6()
    {
        final List<String> lines = readInstructions("examples/boundaryTest4EC4n5n6.s");
        Machine m = new Machine();
        m.execute(lines);
    }

    //boundary tests for valid EC 7
    @Test(expected = NoReturnValueException.class)
    public void boundaryTest4EC7_a()
    {
        final List<String> lines = readInstructions("examples/boundaryTest4EC7_a.s");
        Machine m = new Machine();
        m.execute(lines);
    }

    //boundary tests for valid EC 7
    @Test(expected = InvalidInstructionException.class)
    public void boundaryTest4EC7_b()
    {
        final List<String> lines = readInstructions("examples/boundaryTest4EC7_b.s");
        Machine m = new Machine();
        throw new InvalidInstructionException();
    }

    //boundary tests for valid EC 8
    @Test public void boundaryTest4EC8_a()
    {
        final List<String> lines = readInstructions("examples/boundaryTest4EC8_a.s");
        Machine m = new Machine();
        assertEquals(m.execute(lines),0);
    }

    //boundary tests for valid EC 8
    @Test(expected = InvalidInstructionException.class)
    public void boundaryTest4EC8_b()
    {
        final List<String> lines = readInstructions("examples/boundaryTest4EC8_b.s");
        Machine m = new Machine();
        throw new InvalidInstructionException();
    }

    //boundary tests for valid EC 9
    @Test public void boundaryTest4EC9()
    {
        final List<String> lines = readInstructions("examples/boundaryTest4EC9.s");
        Machine m = new Machine();
        assertEquals(m.execute(lines),100);
    }

    //boundary tests for invalid EC 1,9

    @Test(expected = InvalidInstructionException.class)
    public void boundaryTest4EC1n9_IV()
    {
        final List<String> lines = readInstructions("examples/boundaryTest4EC1n9_IV.s");
        Machine m = new Machine();
        assertEquals(m.execute(lines),300);
    }

    //boundary tests for invalid EC 2,10
    @Test(expected = InvalidInstructionException.class)
    public void boundaryTest4EC2n10_IV()
    {
        final List<String> lines = readInstructions("examples/boundaryTest4EC2n10_IV.s");
        Machine m = new Machine();
        m.execute(lines);
    }

    //boundary tests for invalid EC 3,4
    @Test(expected = InvalidInstructionException.class)
    public void boundaryTest4EC3n4_IV()
    {
        final List<String> lines = readInstructions("examples/boundaryTest4EC3n4_IV.s");
        Machine m = new Machine();
        throw new InvalidInstructionException();
    }

    //boundary tests for invalid EC 5
    @Test public void boundaryTest4EC5_IV()
    {
        final List<String> lines = readInstructions("examples/boundaryTest4EC5_IV.s");
        Machine m = new Machine();
        assertEquals(m.execute(lines),0);
    }

    //boundary tests for invalid EC 6
    @Test public void boundaryTest4EC6_IV()
    {
        final List<String> lines = readInstructions("examples/boundaryTest4EC6_IV.s");
        Machine m = new Machine();
        assertEquals(m.execute(lines),0);
    }

    //boundary tests for invalid EC 11
    @Test public void boundaryTest4EC11_IV()
    {
        final List<String> lines = readInstructions("examples/boundaryTest4EC11_IV.s");
        Machine m = new Machine();
        assertEquals(m.execute(lines),1);
    }

    //boundary tests for invalid EC 12
    @Test(expected = InvalidInstructionException.class)
    public void boundaryTest4EC12_IV()
    {
        final List<String> lines = readInstructions("examples/boundaryTest4EC12_IV.s");
        Machine m = new Machine();
        m.execute(lines);
    }

    //boundary tests for invalid EC 14
    @Test(expected = NoReturnValueException.class)
    public void boundaryTest4EC14_IV()
    {
        final List<String> lines = readInstructions("examples/boundaryTest4EC14_IV.s");
        Machine m = new Machine();
        m.execute(lines);
    }

  //Read in a file containing a program and convert into a list of
  //string instructions
  private List<String> readInstructions(String file)
  {
    Charset charset = Charset.forName("UTF-8");
    List<String> lines = null;
    try {
      lines = Files.readAllLines(FileSystems.getDefault().getPath(file), charset);
    }
    catch (Exception e){
      System.err.println("Invalid input file! (stacktrace follows)");
      e.printStackTrace(System.err);
      System.exit(1);
    }
    return lines;
  }
}
