# SWEN90006-A1-2018

Assignment code for SWEN90006 (Software Testing and Reliability) at the University of Melbourne. Semester 2, 2018.

The folder structure is:

- src/ contains the source code for the virtual machine.
- test/ contains the templates for the JUnit test scripts.
- mutants/ contains five identical copies of the src, which you must modify to create your mutants.
- examples/ contains two example programs using the simple language.
- build.xml is an ant build script that you can choose to use or not
