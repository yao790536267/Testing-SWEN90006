package swen90006.machine;

public class InvalidInstructionException extends RuntimeException
{
  public String toString()
  {
      return "InvalidInstructionException";
  }
}
