import java.io.IOException;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Random;


/* a stub for your team's fuzzer */
public class Fuzzer {

    private static final String OUTPUT_FILE = "fuzz.s";
    
    private static final String STATUS_FILE = "status.txt";
    
    
    //********************written by student***************************************
    private static int rx=0,ry=34;    //randomly generate Rx ~Ry
    private static int min= -65537, max = 65537 ; //randomly generate value from min to max
    private static Instruction[] INSTS = Instruction.values(); //all instructions
    //used to store the number of instructions having been made
    private static int number=0;
    
    //randomly generate Rx ~ Ry and R32 is quite often
    public static String getRegisterMore32() {
    	int value = getInt(rx,ry);
    	if(value>=32) {
    		if(getInt(0,1)==0)value=32;
    	}
    	String number = String.valueOf(value);
    	return "R"+number;
    }
    
    //randomly generate min ~ max
    public static String getMaybeWrongValue() {
    	String value="0";
    	if(new Random().nextBoolean()) {
    		value = String.valueOf(getInt(65510,max));
    	}else {
    		value = String.valueOf(getInt(min,-65510));
    	}
    	
    	return value;
    }
    
    //randomly generate valid Register
    public static String getValidRegister() {
    	int num = getInt(0,31);
    	if(num!=31&&getInt(1,16)==15) num=31;
    	String number = String.valueOf(num);
    	return "R"+number;
    }
    
    //
  //randomly generate min ~ max
    public static String getValidValue() {
    	String value = String.valueOf(getInt(-65535,65536));
    	return value;
    }
    
    //randomly generate integer>=1
    public static String getUpZero() {
    	String value = String.valueOf(getInt(2,4));
    	return value;
    }
    
    //randomly generate an integer between x and y
    public static int getInt(int x,int y) {
    	return x + (int)(Math.random() * (y - x + 1));
    }
    //*********************************************************************
    public static void main(String[] args) throws IOException {
    	
    	FileInputStream in=null;
    	FileOutputStream statusOut=null;
    	PrintWriter pwS = null;
    	
    	
        FileOutputStream out = null;
        PrintWriter pw = null;
        try {
            out = new FileOutputStream(OUTPUT_FILE);
            pw = new PrintWriter(out);
            
            in=new FileInputStream(STATUS_FILE);
            InputStreamReader isr = new InputStreamReader(in, "utf-8");
            BufferedReader br = new BufferedReader(isr);
            String status=br.readLine();
            int st=Integer.parseInt(status);
            br.close();
            isr.close();
            in.close();
            
            BufferedWriter writer = new BufferedWriter(new FileWriter(new File(STATUS_FILE),false));
            
            
            
          //  statusOut= new FileOutputStream(STATUS_FILE);
          //  pwS=new PrintWriter(statusOut);
            if(st!=20) {
            	writer.write(String.valueOf(st+1));
            //	pwS.print(String.valueOf(st));
            }else {
            	writer.write("1");
           // 	pwS.print("1");
            }
          //  pwS.flush();
         //   pwS.close();
           // statusOut.close();
            writer.close();
            
            //*******relatively fixed part start*******************
            pw.println("");
            number++;
            pw.println("MOV R0 -1");
            number++;
            pw.println("MOV R1 1");
            number++;
            pw.println("DIV R31 R0 R1");
            number++;
            pw.println("ADD R0 R0 R1");
            number++;
            pw.println("JZ R0 -1");
            number++;
            pw.println("MOV R0 -2");
            number++;
            pw.println("ADD R0 R0 R1");
            number++;
            pw.println("JZ R0 5");
            number++;
            
            pw.println("MOV R31 0");
            number++;
            pw.println("STR R31 65535 R31");
            number++;
            pw.println("LDR R30 R31 65535");
            number++;
            if(st>=3) {
            	pw.println("JMP -5");
            	number++;
            }else {
            	if(st==1) {      //visit memory 65536 as boundary 
            		String v;
            		if(new Random().nextBoolean()) v="65536";
            		else v="65537";
            		pw.println("MOV R3 0");
            		number++;
            		pw.println("STR R3 "+v+" R1");
            		number++;
            		pw.println("LDR R1 R3 "+v);
            		number++;
            		pw.println("JMP -8");
            		number++;
            	}else {
            		pw.println("JMP -13");
            		number++;
            	}
            }
            //*******relatively fixed part end************************
            
            Instruction instruction;
            OperandType[] operands; //used to get valid operands type
            String inst;
            //*************random part 1 where more mistakes will be made, but RET will not shown*****
          //whether generate an instruction logner than 1022
            if(st==3) {
            	String overline="ADD R2 R2 R2";
            	while(overline.length()<=1022) {
            		overline+=" R2";
            	}
            	overline=overline.substring(0, 1023);
            	pw.println(overline);
            	number++;
            }
            for(int i =0;i<5;i++) {
            	inst="";
            	instruction = INSTS[getInt(0,9)];
            	while(instruction.getOpcode().equals("ret")) instruction = INSTS[getInt(0,9)];
            	inst+=instruction.getOpcode().toUpperCase();
            	operands=instruction.getOperands();
            	if(!instruction.getOpcode().equals("jz")&&!instruction.getOpcode().equals("jmp")){
            		for(OperandType type : operands) {
            			if(type.toString().equals("REGISTER")) {
            				inst+=" "+getRegisterMore32();                    //get more R32
            			}else {
            				inst+=" "+getMaybeWrongValue();
            			}
            		}
            		if(25==getInt(1,100)) {
            			inst+=" "+getValidRegister();
            		}
            	}else {
            		for(OperandType type : operands) {
            			if(type.toString().equals("REGISTER")) {
            				inst+=" "+getRegisterMore32();                //get more R32
            			}else {
            				inst+=" "+getUpZero();
            			}
            		}
            		if(25==getInt(1,100)) {
            			inst+=" "+getValidRegister();
            		}
            	}
            	if(new Random().nextBoolean()) {
            		inst+="        ;"+getValidRegister();
            	}
            	pw.println(inst);
            	number++;
            }
            
            
         /*   
            //testing the memory of "STR" and "LDR"
            if(getInt(1,4)==4) {
            	inst="";
            	instruction = INSTS[getInt(5,6)];
            	inst+=instruction.getOpcode().toUpperCase();
            	operands=instruction.getOperands();
            	for(OperandType type : operands) {
        			if(type.toString().equals("REGISTER")) {
        				inst+=" "+getRegisterMore32();                    //get more R32
        			}else {
        				inst+=" "+getMaybeWrongValue();
        			}
        		}
            	
            }*/
           
            
            //************random part 2 end***********************************
            
            //***********random part 2 where less mistakes will be made start***************
            
            boolean flag =true;  //turned to false when RET is created

            boolean ifTooManyLines = false;      //whether generate over 65536 instructions
            if(st==4) ifTooManyLines=true;
            
            
            while(flag) {
            	inst="";
            	instruction = INSTS[getInt(0,9)];
            	if(instruction.getOpcode().equals("ret")) {   //sometimes "RET" will not be generated
            		flag=false;
            		int intFlag = getInt(0,4);
            		if(ifTooManyLines&&number<=65536) {flag=true;}
            		else if(intFlag==0) {      //no "RET"
            			break;
            		}else if(intFlag==1) {   //more "RET"
            			flag=true;
            		}else {}                 //one "RET"
            		

            	}
            	inst+=instruction.getOpcode().toUpperCase();
            	operands=instruction.getOperands();
            	if(!instruction.getOpcode().equals("jz")&&!instruction.getOpcode().equals("jmp")){
            		for(OperandType type : operands) {
            			if(type.toString().equals("REGISTER")) {
            				inst+=" "+getValidRegister();
            			}else {
            				inst+=" "+getValidValue();
            			}
            		}
            	}else {
            		for(OperandType type : operands) {
            			if(type.toString().equals("REGISTER")) {
            				inst+=" "+getValidRegister();
            			}else {
            				inst+=" "+getUpZero();
            			}
            		}
            	}
            	if(new Random().nextBoolean()) {
            		inst+="       ;"+getValidRegister();
            	}
            	pw.println(inst);
            	number++;
            	
            	if(number==65537) break;
            	
            }
            //************random part end******************
            /* We just print one instruction.
               Hint: you might want to make use of the instruction
               grammar which is effectively encoded in Instruction.java */

            System.out.println("Finished!");

            
        }catch (Exception e){
            e.printStackTrace(System.err);
            System.exit(1);
        }finally{
            if (pw != null){
                pw.flush();
            }
            if (out != null){
                out.close();
            }
        }

    }

}
