public enum OperandType {
    REGISTER, VALUE
}
